# aws-test-server

This repository is a test for connection with AWS.
